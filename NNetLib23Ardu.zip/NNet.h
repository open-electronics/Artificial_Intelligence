/**************************************************************************************

Neural Networks library. It can works also on Arduino platform.
If it runs on Arduino you have to uncomment "#define ARDUINONNET"
By contrast, if library is used on computer, you have to comment this define statement.

You can use Neural Network of 3 layer.
Each layer can have any number of nodes.
Layer 0 is the input layer (just to collect input values); transfer function is linear.
Layer 1 is the hidden layer. Each node summarize inputs weighted by input links.
For this layer you can chose from different transfer functions.
Layer 2 is the output layer. You can collect result value from this layer.
Also this layer summarize weighted hidden values.
You can chose transfer function from different model.
Transfer functions provided in this version:
- NodeLin  (linear function; fixed for layer 0)
- NodeSigm (sigmoid function = 1/(1+exp(-x))
- NodeTanh (hyperbolic tangent = (exp(x)-exp(-x))/(exp(x)+exp(-x))
- NodeReLU (Rectified LinearUnit = 0.1*x if x<0 else just x

Nerual Network can be defined with random weight for training phase or
can be defined with correct value for use it.
- Random definition:   NNet(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type);
- complete definition: NNet(char netdef[]); (by definition string)
                       NNet(const char* filename);  (by file; not for Arduino)
                       save(const char* filename);  (save on file; not for Arduino)

Examples:
Definition of a random net of 2 input nodes, 2 hidden NodeTanh and one NodeLin for output layer
   NNet net(2,2,"NodeTanh",1,"NodeLin");

Creation of similar neural network but with exact weight values
   NNet(char netdef[]);

   where netdef string is defined as:
   char* netdef=
    "L0 2 "                      //layer 0 with 2 nodes
    "L1 2 NodeTanh "             //layer 1 with 2 nodes NodeTanh
    "HLW0 -2.3404 -2.3427 "      //Hidden_Layer_Weigth_ofnode0 value_from_node_0_oflayer0 ...
    "HLW1 0.4820 0.4669 "        //  "       "    "          1    "        "
    "L2 1 NodeLin "              //layer 2 with 1 node NodeLin
    "OLW0 -2.3558 -3.0901";      //Output_Layer_Weight_ofnode0 value_from_node_0_oflayer1 ...
NB. Always separate token with spaces!

********************************************************************************************/

#ifndef NNET_H
#define NNET_H
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define RA -0.1
#define RB +0.1
#define EPS 0.1

#define ARDUINONNET    //uncomment if used on ARDUINO or comment if not

class NNet
{
    public:
/** Definition of random nnet (nnet to train):
    L0n: number of nodes of layer 0
    L1n: number of nodes of layer 1
    L1Type; name of transfer function used by layer 1
    L2n: number of nodes of layer 2
    L2Type: name of transfer function used by layer 2 */
        NNet(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type);

/** Creation of a nnet described in netdef string */
        NNet(char netdef[]);

#ifndef ARDUINONNET
/** Creation of a nnet described in file with name filename (not Arduino)*/
        NNet(const char* filename);
#endif // NOARDUINO

        virtual ~NNet();

/** Basic exploitation function.
    inp array has to contain input values and out array is the buffer that collect result
    (diminp: input array size; dimout: output array size)*/
        void forw(float inp[],int diminp,float out[],int dimout);

/** Training function.
    train array is the forced output supplied by user.
    Function returns the squared mean error */
        float learn(float inp[],int diminp,float train[],int dimtrain);

/** Print nnet structure*/
        void print();

#ifndef ARDUINONNET
/** Save nnet structure on file*/
        void save(char* filename);
        void savexardu(char* filename);
#endif // NOARDUINO

/* Utilities */
        void getHiddenOut(float out[],int dimout);
        void getWeightsL1fromL0(int nodeL1,float w[],int dimw);
        void getWeightsL2fromL1(int nodeL2,float w[],int dimw);

    protected:

    private:
        int lay0n;
        int lay1n;
        int lay2n;
        struct Lhid
        {
           float inp;
           float out;
           float err;
           float* wgt;
        };
        struct Lout
        {
           float inp;
           float out;
           float* wgt;
        };
        Lhid*  hidn;
        Lout*  outn;

        float (*frw1)(float act);
        float (*frw2)(float act);
        float (*learn1)(float out);
        float (*learn2)(float out);

        void decodeType1(const char* ty);
        void decodeType2(const char* ty);
        char ty1[20];
        char ty2[20];

#ifndef ARDUINONNET
        void outdef(FILE* fp,bool ardu);
#endif // ARDUINO

        int readval(char* token);
        int decode(char* token);
        void getToken(char* netdef,char token[],int lentok, int* next);

        int cnti,cntj;
        int state;

};

#endif // NNET_H
