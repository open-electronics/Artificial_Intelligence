#include "NNet.h"


float fmax(float a,float b){return a>b?a:b ;}
float fmin(float a,float b){return a<b?a:b ;}
int imax(int a,int b){return a>b?a:b ;}
int imin(int a,int b){return a<b?a:b ;}

float rnd(float a, float b)
{
    float r=rand();
    r=r/RAND_MAX;r= r * (b-a);r=r+a;
    return r;
}

/**********************************************************************/


NNet::NNet(int L0n,int L1n,const char* L1Type,int L2n,const char* L2Type)
{
   lay0n=L0n;
   lay1n=L1n;
   lay2n=L2n;
   decodeType1(L1Type);
   decodeType2(L2Type);
   hidn=new Lhid[lay1n];
   outn=new Lout[lay2n];

   for (int i=0;i<lay1n;i++)
   {
       Lhid* hid=&hidn[i];
       hid->inp=0;
       hid->err=0;
       hid->out=0;
       hid->wgt=new float[lay0n];
       for (int j=0;j<lay0n;j++){hid->wgt[j]=rnd(RA,RB);}
   }

   for (int i=0;i<lay2n;i++)
   {
       Lout* out=&outn[i];
       out->inp=0;
       out->out=0;
       out->wgt=new float[lay1n];
       for (int j=0;j<lay1n;j++){out->wgt[j]=rnd(RA,RB);}
   }
}

NNet::~NNet()
{}

void NNet::forw(float inp[],int diminp,float out[],int dimout)
{
   int din=imin(diminp,lay0n);
   int dou=imin(diminp,lay2n);

   for (int i=0;i<lay1n;i++)
   {
       float act=0;
       for (int k=0;k<lay0n;k++)
       {act=act+hidn[i].wgt[k]*inp[k];}
       hidn[i].out=(*frw1)(act);
       hidn[i].err=0;
   }

   for (int i=0;i<lay2n;i++)
   {
       float act=0;
       for (int k=0;k<lay1n;k++)
       {act=act+outn[i].wgt[k]*hidn[k].out;}
       outn[i].out=(*frw2)(act);
   }
   for (int i=0;i<dou;i++) out[i]=outn[i].out;
}

float NNet::learn(float inp[],int diminp,float train[],int dimtrain)
{
   int din=imin(diminp,lay0n);
   int dou=imin(dimtrain,lay2n);
   float out[lay2n];
   float errq=0;

   forw(inp,diminp,out,lay2n);

   for (int i=0;i<dou;i++)
    {
        float diff=out[i]-train[i];
        errq=errq+(diff*diff);
        float erri=-0.5*diff;
        erri=erri*(*learn2)(out[i]);
        float errk;
        for (int k=0;k<lay1n;k++)
        {
           errk=erri * outn[i].wgt[k];
           hidn[k].err=hidn[k].err + errk;
           float dw=EPS*erri * hidn[k].out;
           outn[i].wgt[k]=outn[i].wgt[k]+dw;
        }
    }
   for (int i=0;i<lay1n;i++)
    {
        float erri=hidn[i].err;;
        erri=erri*(*learn1)(hidn[i].out);
        for (int k=0;k<lay0n;k++)
        {
           float dw=EPS*erri * inp[k];
           hidn[i].wgt[k]=hidn[i].wgt[k]+dw;
        }
    }
    return errq/lay2n;
}

#ifdef ARDUINONNET
#include <ARDUINO.h>
void NNet::print()
{
    Serial.print("L0 ");Serial.print(lay0n);Serial.println();
    Serial.print("L1 ");Serial.print(lay1n);Serial.print(" ");Serial.print(ty1);Serial.println();
    for (int i=0;i<lay1n;i++)
    {
        Serial.print("HLW");Serial.print(i);Serial.print(" ");
        for (int j=0;j<lay0n;j++)
        {Serial.print(hidn[i].wgt[j],4);Serial.print(" ");}
        Serial.println();
    }
    Serial.print("L2 ");Serial.print(lay2n);Serial.print(" ");Serial.print(ty2);Serial.println();
    for (int i=0;i<lay2n;i++)
    {
        Serial.print("OLW");Serial.print(i);Serial.print(" ");
        for (int j=0;j<lay1n;j++)
        {Serial.print(outn[i].wgt[j],4);Serial.print(" ");}
        Serial.println();
    }
}

#else

void NNet::print()
{
    outdef(stdout,false);
}

void NNet::save(char* filename)
{
    FILE* fp;
    fp=fopen(filename,"w");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);return;}
    outdef(fp,false);
}

void NNet::savexardu(char* filename)
{
    FILE* fp;
    fp=fopen(filename,"w");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);return;}
    outdef(fp,true);
}

void NNet::outdef(FILE* fp,bool ardu)
{
    char q[3]="";char pc[3]="";
    if (ardu){strcpy(q,"\"");strcpy(pc,";");}
    fprintf(fp,"%sL0 %d %s\n",q,lay0n,q);
    fprintf(fp,"%sL1 %d %s %s\n",q,lay1n,ty1,q);
    for (int i=0;i<lay1n;i++)
    {
        fprintf (fp,"%sHLW%d ",q,i);
        for (int j=0;j<lay0n;j++)
        {fprintf(fp,"%6.4f ",hidn[i].wgt[j]);}
        fprintf(fp,"%s\n",q);
    }
    fprintf(fp,"%sL2 %d %s %s\n",q,lay2n,ty2,q);
    for (int i=0;i<lay2n;i++)
    {
        fprintf (fp,"%sOLW%d ",q,i);
        for (int j=0;j<lay1n;j++)
        {fprintf(fp,"%6.4f ",outn[i].wgt[j]);}
        fprintf(fp,"%s\n",q);
    }
    fprintf(fp,"%s",pc);
}

NNet::NNet(const char* filename)
{
    FILE* fp;
    fp=fopen(filename,"r");
    if (fp==NULL) {printf("Can't open file: %s\n",filename);}
    char token[10];
    int err=0;
    state=0;cnti=0;cntj=0;
    while (fscanf(fp,"%s",token)>0)
        {err=decode(token);if (err<0) return ;}
    return ;
}

#endif // NOARDUINO

NNet::NNet(char netdef[])
{
    char token[10];
    int err=0;
    state=0;cnti=0;cntj=0;
    int p=0;
    int n=0;
    while (p<strlen(netdef))
       {sscanf(&netdef[p],"%s%*[' ']%n",token,&n);
        p=p+n;
        err=decode(token);if (err<0) return ;}
    return ;
}


int NNet::readval(char* token)
{
    switch (state)
    {
       case 1 : lay0n=atoi(token);break;
       case 2 : lay1n=atoi(token);hidn=new Lhid[lay1n];state=8;break;
       case 3 : lay2n=atoi(token);outn=new Lout[lay2n];state=9;break;
       case 4 : cnti=atoi(&token[3]);hidn[cnti].wgt=new float[lay0n];cntj=0;state=6;break;
       case 5 : cnti=atoi(&token[3]);outn[cnti].wgt=new float[lay1n];cntj=0;state=7;break;
       case 6 : hidn[cnti].wgt[cntj]=atof(token);cntj++;break;
       case 7 : outn[cnti].wgt[cntj]=atof(token);cntj++;break;
       case 8 : decodeType1(token);break;
       case 9 : decodeType2(token);break;
    }
    return 0;
}

int NNet::decode(char* token)
{
    if (strncasecmp(token,"L0",2)==0) {state=1;return 0;}
    if (strncasecmp(token,"L1",2)==0) {state=2;return 0;}
    if (strncasecmp(token,"L2",2)==0) {state=3;return 0;}
    if (strncasecmp(token,"HLW",3)==0) {state=4;readval(token);return 0;}
    if (strncasecmp(token,"OLW",3)==0) {state=5;readval(token);return 0;}
    return readval(token);
}

void NNet::getHiddenOut(float out[],int dimout)
{
    int k=imin(lay1n,dimout);
    for (int i=0;i<k;i++)out[i]=hidn[i].out;
}

void NNet::getWeightsL1fromL0(int nodeL1,float w[],int dimw)
{
    int n=imin(nodeL1,lay1n);
    int k=imin(dimw,lay0n);
    for (int i;i<dimw;i++) w[i]=hidn[n].wgt[i];
}

void NNet::getWeightsL2fromL1(int nodeL2,float w[],int dimw)
{
    int n=imin(nodeL2,lay2n);
    int k=imin(dimw,lay1n);
    for (int i;i<dimw;i++) w[i]=outn[n].wgt[i];
}

/*********************************************************************/
#define NRELU 0.1

float linfrw(float x){return x;}
float linlrn(float y){return 1;}

float sigmfrw(float x){return 1/(1+exp(-x));}
float sigmlrn(float y){return y-(1-y);}

float tanhfrw(float x){float a=exp(x);float b=exp(-x);return (a-b)/(a+b);}
float tanhlrn(float y){return 1-(y*y);}

float ReLUfrw(float x){return x<0?NRELU*x:x ;}
float ReLUlrn(float y){return y<0?NRELU:1 ;}

typedef float (*pf)(float x);

void decodefun(const char* ty,pf &fa,pf &fb)
{
       if (strncasecmp(ty,"NodeLin",7)==0)  {fa=linfrw;fb=linlrn;}
       if (strncasecmp(ty,"NodeSigm",8)==0) {fa=sigmfrw;fb=sigmlrn;}
       if (strncasecmp(ty,"NodeTanh",8)==0) {fa=tanhfrw;fb=tanhlrn;}
       if (strncasecmp(ty,"NodeReLU",8)==0) {fa=ReLUfrw;fb=ReLUlrn;}
}


void NNet::decodeType1(const char* ty)
{
    decodefun(ty,frw1,learn1);
    strncpy(ty1,ty,20);
}

void NNet::decodeType2(const char* ty)
{
    decodefun(ty,frw2,learn2);
    strncpy(ty2,ty,20);
}
