# play video from Web-Camera number 0

./darknet detector  demo  -w 416 -h 416 -fullscreen cfg/voc.data cfg/yolov2-tiny-voc.cfg yolov2-tiny-voc.weights -c 0 
