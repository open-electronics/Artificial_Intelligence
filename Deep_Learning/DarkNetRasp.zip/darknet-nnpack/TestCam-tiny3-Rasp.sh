# play video from Web-Camera number 0

./darknet detector  demo  -w 416 -h 416 -fullscreen cfg/coco.data cfg/yolov3-tiny.cfg yolov3-tiny.weights -c 0 
